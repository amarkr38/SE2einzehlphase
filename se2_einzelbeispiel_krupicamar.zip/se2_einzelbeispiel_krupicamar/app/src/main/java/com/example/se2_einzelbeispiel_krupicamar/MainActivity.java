package com.example.se2_einzelbeispiel_krupicamar;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import java.io.*;
import java.net.Socket;


;

public class MainActivity extends AppCompatActivity {
    EditText editTextName;
    Button Abschicken;
    TextView Antwort;
    private Socket socket;
    private OutputStream output;
    private PrintWriter printWriter;
    private BufferedReader bufferedReader;
    private String antwortVomServer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextName = (EditText) findViewById(R.id.editText);
        Antwort = (EditText) findViewById(R.id.Antwort);

        Abschicken = (Button) findViewById(R.id.button2);
        Abschicken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String string = editTextName.getText().toString();

                int i = Integer.parseInt(string);

                String binary = Integer.toBinaryString(i);

                Antwort.setText("Binary: " + binary);

            }
        });


        Button clear = (Button) findViewById(R.id.clear);
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTextName.setText("");
                Antwort.setText("");

            }
        });

    }


    public String workingWithServer() {

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {

                EditText editText = (EditText) findViewById(R.id.editText);
                try {
                    socket = new Socket("se2-isys.aau.at", 53212);
                    output = socket.getOutputStream();
                    printWriter = new PrintWriter(output, true);
                    printWriter.println(editText.getText().toString());
                    bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    antwortVomServer = bufferedReader.readLine();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return antwortVomServer;
    }
}















